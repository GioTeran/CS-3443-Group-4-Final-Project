package application;

public class StudentController {

}
