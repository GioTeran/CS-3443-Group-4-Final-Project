/**
 * This controller is for the Status FXML file
 */
package application.controller;

public class Scene2Controller {

}
