/**
 * This controller is for the Estimate fxml file
 */
package application.controller;

public class Scene5Controller {

}
