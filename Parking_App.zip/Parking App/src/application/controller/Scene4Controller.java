/**
 * This controller is for the DaysHours FXML file
 */
package application.controller;

public class Scene4Controller {

}
