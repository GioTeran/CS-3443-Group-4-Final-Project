/**
 * This is the controller for the Parking Model
 */
package application.controller;

public class Scene6Controller {

}
