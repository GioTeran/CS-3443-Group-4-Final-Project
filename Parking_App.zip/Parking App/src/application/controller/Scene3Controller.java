/**
 * This controller is for Permit Selection FXML file
 */
package application.controller;

public class Scene3Controller {

}
