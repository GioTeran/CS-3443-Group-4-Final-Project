/**
 * This is the itinerary setup scene. Here we will set up the days and hours that the
 * client will be using the parking spot
 */
package application.model;

public class Scene4 {

}
