/**
 * This is the status scene
 */
package application.model;

public class Scene2 {

}
