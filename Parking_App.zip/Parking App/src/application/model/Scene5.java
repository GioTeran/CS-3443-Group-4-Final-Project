/**
 * This scene is for the Cost Estimator
 * 
 */
package application.model;

public class Scene5 {

}
