/**
 * This is the java file for the parking model scene
 */
package application.model;

public class Scene6 {

}
