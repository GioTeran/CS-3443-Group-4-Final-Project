/**
 * This is the permit selection scene
 */
package application.model;

public class Scene3 {

}
